package com.example.pcbox_android_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Layout;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pcbox_android_app.Model.Produktua;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class Katalogoa extends AppCompatActivity {
    private static Connection conexion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_katalogoa);
        String txtErabiltzailea_Bidalia = getIntent().getExtras().getString("txtErabiltzailea");
        TextView txtErabiltzailea = (TextView)findViewById(R.id.txtErabiltzailea);
        txtErabiltzailea.setText(txtErabiltzailea_Bidalia);
        ImageView btnHasiera = (ImageView)findViewById(R.id.btnHasiera);
        ImageView btnErosketa = (ImageView)findViewById(R.id.btnErosketa);
        ImageView btnKatalogoa = (ImageView)findViewById(R.id.btnKatalogoa);
        btnHasiera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Home.class);
                intent.putExtra("txtErabiltzailea",txtErabiltzailea.getText().toString());
                startActivity(intent);
            }
        });
        btnErosketa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Erosketa.class);
                intent.putExtra("txtErabiltzailea",txtErabiltzailea.getText().toString());
                startActivity(intent);
            }
        });
        ScrollView scrollView = (ScrollView)findViewById(R.id.scrolKatalogoa);
        LinearLayout linearLayoutScroll = findViewById(R.id.layoutScroll);
        ArrayList<Produktua> produktuenZerrenda = Produktua.irakurriProduktuak();
        for(int i = 0; i < produktuenZerrenda.size(); i++){
            DecimalFormat format = new DecimalFormat();
            format.setMaximumFractionDigits(2); //2 dezimal ezartzen ditu formatua eman nahi den elementuari;
            String prezioa = format.format(produktuenZerrenda.get(i).getPrezioa()) + "€";
            TextView txtPrezioa = new TextView(this);
            txtPrezioa.setText(prezioa);
            txtPrezioa.setTextSize(20);
            txtPrezioa.setTextColor(Color.parseColor("#000000"));

            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            linearLayout.setPadding(0,0,0,50);

            TextView txtProduktua = new TextView(this);
            txtProduktua.setText(produktuenZerrenda.get(i).getProduktua());
            txtProduktua.setTextSize(20);
            txtProduktua.setTextColor(Color.parseColor("#000000"));

            ImageView imgProduktua = new ImageView(this);
            imgProduktua.setImageResource(R.drawable.glogoatxiki);

            linearLayout.addView(imgProduktua);
            linearLayout.addView(txtProduktua);
            linearLayout.addView(txtPrezioa);
            linearLayoutScroll.addView(linearLayout);
        }
    }
}