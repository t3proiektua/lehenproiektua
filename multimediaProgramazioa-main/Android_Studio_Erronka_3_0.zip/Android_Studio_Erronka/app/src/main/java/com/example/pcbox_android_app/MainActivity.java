package com.example.pcbox_android_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {
    private static boolean status;
    private static final String db = "Odoo_Ethazi";
    //Si estás utilizando el emulador de Android y tienes el PostgreSQL en tu misma PC no debes utilizar 127.0.0.1 o localhost como IP, debes utilizar 10.0.2.2
    private static final String url = "jdbc:postgresql://192.168.65.41:5432/" + db;
    private static final String user = "admin";
    private static final String password = "admin";
    private static Connection conexion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnHasiSaioa = (Button)findViewById(R.id.btnHasiSaioa);
        EditText txtErabiltzailea= (EditText)findViewById(R.id.txtErabiltzailea);
        EditText txtPasahitza = (EditText)findViewById(R.id.txtPasahitza);
        btnHasiSaioa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Connection conn = conexionBD2();
                Connection conexionBD = conexionBD();
                Boolean loginResult = true;//LogIn(txtErabiltzailea.getText().toString(),txtPasahitza.getText().toString());
                if(loginResult){
                    //Hurrengo pantailara joan
                    Intent intent = new Intent(getApplicationContext(), Home.class);
                    intent.putExtra("txtErabiltzailea",txtErabiltzailea.getText().toString());
                    startActivity(intent);
                }
            }
        });
    }
    //Creamos nuestra funcion para Conectarnos a Postgresql
    public Connection conexionBD(){

        try{
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("org.postgresql.Driver");
            conexion = DriverManager.getConnection(url, user, password);
        }catch (Exception er){
            System.err.println("Error Conexion"+ er.toString());
            Toast toast = Toast.makeText(getApplicationContext(), "Ez da konektatu", Toast.LENGTH_SHORT);
            toast.show();
        }
        return  conexion;
    }
    /*public static Connection conexionBD2(){

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Class.forName("org.postgresql.Driver");
                    conexion = DriverManager.getConnection(url, user, password);
                    status = true;
                    Log.i("konexioa", "DB connected:" + true);
                } catch (Exception e) {
                    status = false;
                    Log.w("konexioa", e.getMessage());
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (Exception e) {
            e.printStackTrace();
            status = false;
        }
        return  conexion;
    }*/

    //Creamos la funcion para Cerrar la Conexion
    protected  void cerrar_conexion(Connection con) throws  Exception{
        con.close();
    }

    /*public static void LogIn2(String user, String password) {

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                Connection conn = conexionBD2();
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    public Boolean LogIn(String user, String password) {
        Boolean result = false;
        String sql = "SELECT * FROM public.Erabiltzaileak WHERE Erabiltzaileak.Erabiltzailea='" + user + "' AND Erabiltzaileak.Pasahitza = '" + password + "'";

        try (Connection conn = conexionBD();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String strUser = rs.getString("Erabiltzailea");
                String strPass = rs.getString("Pasahitza");

                if (strUser.equals(user) && strPass.equals(password)) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Zuzena da", Toast.LENGTH_SHORT);
                    toast.show();
                    result = true;
                    break;
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        try {
            cerrar_conexion(conexion);
        } catch (Exception er) {
            System.err.println("Error al cerrar Conexion"+ er);
        }
        return result;
    }
}