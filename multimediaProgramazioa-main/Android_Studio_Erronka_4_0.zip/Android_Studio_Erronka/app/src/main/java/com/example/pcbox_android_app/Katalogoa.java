package com.example.pcbox_android_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Katalogoa extends AppCompatActivity {
    private static Connection conexion;
    private static final String db = "Odoo_Ethazi";
    private static final String url = "jdbc:postgresql://10.0.2.2:5432/" + db;
    private static final String user = "admin";
    private static final String password = "admin";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_katalogoa);
        String txtErabiltzailea_Bidalia = getIntent().getExtras().getString("txtErabiltzailea");
        TextView txtErabiltzailea = (TextView)findViewById(R.id.txtErabiltzailea);
        txtErabiltzailea.setText(txtErabiltzailea_Bidalia);
        ImageView btnHasiera = (ImageView)findViewById(R.id.btnHasiera);
        ImageView btnErosketa = (ImageView)findViewById(R.id.btnErosketa);
        ImageView btnKatalogoa = (ImageView)findViewById(R.id.btnKatalogoa);
        btnHasiera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Home.class);
                intent.putExtra("txtErabiltzailea",txtErabiltzailea.getText().toString());
                startActivity(intent);
            }
        });
        btnErosketa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Erosketa.class);
                intent.putExtra("txtErabiltzailea",txtErabiltzailea.getText().toString());
                startActivity(intent);
            }
        });
        //llamar a funcion cogerFotos y poner el arraylist que devuelve en el scroolview
    }
    private static ArrayList <String> cogerFotos() {
        ArrayList <String> fotos = new ArrayList<String>();
        ArrayList <String> fotoIndividual = new ArrayList<String>();
        Connection conexion = connectDB();
        if (conexion != null) {
            try {
                String query = "SELECT * FROM product_template";
                ResultSet rs = conexion.createStatement().executeQuery(query);
                while (rs.next()) {
                    //Coger los datos de la base de datos: id, nombre, precio, imagen,...?
                   System.out.println(rs.getString("id"));
                    fotoIndividual.add(rs.getString("id"));
                    System.out.println(rs.getString("nombre"));
                    fotoIndividual.add(rs.getString("nombre"));
                    //...
                }
                fotos.add(fotoIndividual.toString());
                conexion.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return fotos;
    }
    private static Connection connectDB() {
        try{
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("org.postgresql.Driver");
            conexion = DriverManager.getConnection(url, user, password);
        }catch (Exception er){
            System.err.println("Error Conexion"+ er.toString());
        }
        return  conexion;
    }
}