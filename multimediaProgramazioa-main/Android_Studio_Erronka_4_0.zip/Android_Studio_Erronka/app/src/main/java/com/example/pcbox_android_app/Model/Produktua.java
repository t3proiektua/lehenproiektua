package com.example.pcbox_android_app.Model;


import static com.example.pcbox_android_app.Model.DatuBaseKonekzioa.connect;

import android.util.Log;

import java.io.File;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Produktua {
    private int id;
    private String produktua;
    private double prezioa;
    private int kantitatea;
    private File argazkia;

    public Produktua() {
    }

    public Produktua(int id, String produktua, double prezioa, int kantitatea, Blob argazkia) {
        this.id = id;
        this.produktua = produktua;
        this.prezioa = prezioa;
        this.kantitatea = kantitatea;
        this.argazkia = (File) argazkia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProduktua() {
        return produktua;
    }

    public void setProduktua(String produktua) {
        this.produktua = produktua;
    }

    public double getPrezioa() {
        return prezioa;
    }

    public void setPrezioa(double prezioa) {
        this.prezioa = prezioa;
    }

    public int getKantitatea() {
        return kantitatea;
    }

    public void setKantitatea(int kantitatea) {
        this.kantitatea = kantitatea;
    }

    public File getArgazkia() {
        return argazkia;
    }

    public void setArgazkia(File argazkia) {
        this.argazkia = argazkia;
    }

    public static ArrayList<Produktua> irakurriProduktuak(){
        ArrayList<Produktua> produktuak = new ArrayList<>();
        String sql = "SELECT * FROM public.produktuak";
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try (Connection conn = connect();
                     PreparedStatement stmt = conn.prepareStatement(sql);
                     ResultSet rs = stmt.executeQuery())  {
                    while (rs.next()) {
                        produktuak.add(new Produktua(rs.getInt("id"), rs.getString("produktua"), rs.getDouble("prezioa"), rs.getInt("kantitatea"), rs.getBlob("argazkia")));
                    }
                } catch (SQLException e) {
                    Log.e("Datu basea", e.getMessage());
                }
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return produktuak;
    }
}
